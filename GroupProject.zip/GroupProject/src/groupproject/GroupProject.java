/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package groupproject;

import Parse.ParseTxtFile;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
/**
 *
 * @author Jay
 */
public class GroupProject {

    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        // TODO code application logic here
        ParseTxtFile parse = new ParseTxtFile();
        String fileName= "room.txt";
        
        FileReader file1 = new 
            FileReader(GroupProject.class.getResource(fileName).getPath());
        //text file here (see if it is empty)
        if (parse.IsItEmpty(file1) == false){
            System.out.print("\nThe file is empty.\n");
            System.exit(0);
        }
        
        //rewind
        FileReader file2 = new 
            FileReader(GroupProject.class.getResource(fileName).getPath());
        //parse it
        if (parse.CorrectNumLines(file2) == false){
            System.out.print("\nWrong format: error 1\n");
            System.exit(0);
        }
        
        //rewind
        FileReader file3 = new 
            FileReader(GroupProject.class.getResource(fileName).getPath());
        if (parse.IsItValid(file3) == false){
            System.out.print("\nWrong format: error 2\n");
            System.exit(0);
        }
        
        System.out.print("\nParsing complete.\n");
    }
    
}
